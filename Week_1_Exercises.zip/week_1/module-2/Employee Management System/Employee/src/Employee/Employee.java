package Employee;
class Employee {
    private int employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Getters and setters
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }


    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        // Create some employees
        Employee employee1 = new Employee(1, "John Doe", "Software Engineer", 50000.0);
        Employee employee2 = new Employee(2, "Jane Smith", "Marketing Manager", 70000.0);
        Employee employee3 = new Employee(3, "Bob Johnson", "Sales Representative", 40000.0);

        // Add employees to the system
        system.addEmployee(employee1);
        system.addEmployee(employee2);
        system.addEmployee(employee3);

        // Search for an employee
        Employee foundEmployee = system.searchEmployee(2);
        if (foundEmployee != null) {
            System.out.println("Employee found: " + foundEmployee.getName());
        } else {
            System.out.println("Employee not found");
        }

        // Traverse and print all employees
        system.traverseEmployees();

        // Delete an employee
        system.deleteEmployee(2);

        // Traverse and print all employees after deletion
        system.traverseEmployees();
    }
}
