package inventory;
import java.util.*;
public class Inventory {
	private Map<Integer, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    // Method to add a product to the inventory
    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    // Method to update a product in the inventory
    public void updateProduct(int productId, Product updatedProduct) {
        if (products.containsKey(productId)) {
            products.put(productId, updatedProduct);
        }
    }

    // Method to delete a product from the inventory
    public void deleteProduct(int productId) {
        if (products.containsKey(productId)) {
            products.remove(productId);
        }
    }
    // Method to get a product from the inventory
    public Product getProduct(int productId) {
        return products.get(productId);
    }

}
