package Task;

public class TaskManagementSystem {
	    private Node head;

	    public TaskManagementSystem() {
	        this.head = null;
	    }

	    // Add a task to the end of the linked list
	    public void addTask(Task task) {
	        Node newNode = new Node(task);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	        }
	    }

	    // Search for a task by taskId
	    public Task searchTask(int taskId) {
	        Node current = head;
	        while (current != null) {
	            if (current.task.getTaskId() == taskId) {
	                return current.task;
	            }
	            current = current.next;
	        }
	        return null;
	    }

	    // Traverse and print all tasks
	    public void traverseTasks() {
	        Node current = head;
	        while (current != null) {
	            System.out.println(current.task);
	            current = current.next;
	        }
	    }

	    // Delete a task by taskId
	    public boolean deleteTask(int taskId) {
	        if (head == null) {
	            return false;
	        }

	        if (head.task.getTaskId() == taskId) {
	            head = head.next;
	            return true;
	        }

	        Node current = head;
	        while (current.next != null) {
	            if (current.next.task.getTaskId() == taskId) {
	                current.next = current.next.next;
	                return true;
	            }
	            current = current.next;
	        }
	        return false;
	    }

	    public static void main(String[] args) {
	        TaskManagementSystem system = new TaskManagementSystem();

	        // Add tasks to the system
	        system.addTask(new Task(1, "Design the system architecture", "Pending"));
	        system.addTask(new Task(2, "Implement the task management module", "In Progress"));
	        system.addTask(new Task(3, "Test the system", "Pending"));

	        // Traverse all tasks
	        system.traverseTasks();

	        // Search for a task
	        Task foundTask = system.searchTask(2);
	        if (foundTask != null) {
	            System.out.println("Task found: " + foundTask);
	        } else {
	            System.out.println("Task not found");
	        }

	        // Delete a task
	        boolean isDeleted = system.deleteTask(2);
	        if (isDeleted) {
	            System.out.println("Task deleted successfully.");
	        } else {
	            System.out.println("Task deletion failed.");
	        }

	        // Traverse all tasks after deletion
	        system.traverseTasks();
	    }
	}


