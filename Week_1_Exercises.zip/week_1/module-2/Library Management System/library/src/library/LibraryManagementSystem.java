package library;
public class LibraryManagementSystem{
	
	    private Book[] books;

	    public LibraryManagementSystem(Book[] books) {
	        this.books = books;
	    }

	    // Method to implement linear search to find books by title
	    public Book linearSearchByTitle(String title) {
	        for (Book book : books) {
	            if (book.getTitle().equals(title)) {
	                return book;
	            }
	        }
	        return null;
	    }

	    // Method to implement binary search to find books by title (assuming the list is sorted)
	    public Book binarySearchByTitle(String title) {
	        int left = 0;
	        int right = books.length - 1;
	        while (left <= right) {
	            int mid = left + (right - left) / 2;
	            if (books[mid].getTitle().equals(title)) {
	                return books[mid];
	            } else if (books[mid].getTitle().compareTo(title) < 0) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }
	        return null;
	    }

	    public static void main(String[] args) {
	        // Create some books
	        Book book1 = new Book(1, "Book 1", "Author 1");
	        Book book2 = new Book(2, "Book 2", "Author 2");
	        Book book3 = new Book(3, "Book 3", "Author 3");
	        Book book4 = new Book(4, "Book 4", "Author 4");
	        Book book5 = new Book(5, "Book 5", "Author 5");

	        // Store books in an array
	        Book[] books = {book1, book2, book3, book4, book5};

	        // Create a library management system
	        LibraryManagementSystem library = new LibraryManagementSystem(books);

	        // Search for a book by title using linear search
	        Book foundBookLinear = library.linearSearchByTitle("Book 3");
	        if (foundBookLinear != null) {
	            System.out.println("Book found using linear search: " + foundBookLinear.getTitle());
	        } else {
	            System.out.println("Book not found using linear search");
	        }

	        // Search for a book by title using binary search
	        Book foundBookBinary = library.binarySearchByTitle("Book 3");
	        if (foundBookBinary != null) {
	            System.out.println("Book found using binary search: " + foundBookBinary.getTitle());
	        } else {
	            System.out.println("Book not found using binary search");
	        }
	    }
	}
