package sorting_customer_orders;

public class Bubble_sort extends orders{
	public static int[] sort(int arr[]) {
		int n = arr.length;
		for(int i = 0; i<n;i++) {
			for(int j=i+1;j<n;j++) {
				if(arr[i]>arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j]=temp;
				}
			}
		}
		return arr;
	}
}
