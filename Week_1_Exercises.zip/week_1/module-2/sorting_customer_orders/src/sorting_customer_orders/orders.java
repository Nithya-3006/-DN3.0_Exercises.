package sorting_customer_orders;
import java.util.*;
public class orders {
	public static void main(String args[]) {
		Bubble_sort b = new Bubble_sort();
		Quick_sort q = new Quick_sort();
		//Creating scanner to get input
		Scanner sc = new Scanner(System.in);
		int n;
        System.out.println("Enter the number of orders:");
		n = sc.nextInt();
		int order_id[] = new int[n];
		String customer_name[] = new String[n];
		int total_price[] = new int[n];
		//Getting the values for order_id, customer_name, total_price
		System.out.println("Enter order_id:");
		for(int i=0;i<n;i++) {
			order_id[i]=sc.nextInt();
		}
		System.out.println("Enter customer_name:");
		for(int i=0;i<n;i++) {
			customer_name[i]=sc.next();
		}
		System.out.println("Enter total_price:");
		for(int i=0;i<n;i++) {
			total_price[i]=sc.nextInt();
		}
		sc.close();
		//Bubble_sort
		b.sort(total_price);
		
		for(int i=0;i<n;i++) {
			System.out.print(order_id[i]+" ");
		}
		System.out.println();
		for(int i=0;i<n;i++) {
			System.out.print(customer_name[i]+" ");
		}
		System.out.println();
		System.out.println("After bubble sort");
		for(int i=0;i<n;i++) {
			System.out.print(total_price[i]+" ");
		}
		
		System.out.println();
		//Quick_sort
		q.quick_sorting(total_price, 0, total_price.length-1);
		System.out.println("After quick sort");
		for(int i=0;i<n;i++) {
			System.out.print(total_price[i]+" ");
		}
		
	}
}
