package ecommerce;

public class Main {
    public static int linearSearch(Product[] products, int targetId) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductId() == targetId) {
                return i; // Return the index of the target product
            }
        }
        return -1; // Return -1 if the target product is not found
    }

    public static int binarySearch(Product[] products, int targetId) {
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId() == targetId) {
                return mid; // Return the index of the target product
            } else if (products[mid].getProductId() < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // Return -1 if the target product is not found
    }

    public static void main(String[] args) {
        // Create some products
        Product product1 = new Product(1, "Product 1", "Category 1");
        Product product2 = new Product(2, "Product 2", "Category 2");
        Product product3 = new Product(3, "Product 3", "Category 3");
        Product product4 = new Product(4, "Product 4", "Category 4");
        Product product5 = new Product(5, "Product 5", "Category 5");

        // Store products in an array for linear search
        Product[] productsLinear = {product1, product2, product3, product4, product5};

        // Store products in a sorted array for binary search
        Product[] productsBinary = {product1, product2, product3, product4, product5};

        // Search for a product using linear search
        int targetId = 3;
        int resultLinear = linearSearch(productsLinear, targetId);
        if (resultLinear != -1) {
            System.out.println("Product found at index " + resultLinear + " using linear search");
        } else {
            System.out.println("Product not found using linear search");
        }

        // Search for a product using binary search
        int resultBinary = binarySearch(productsBinary, targetId);
        if (resultBinary != -1) {
            System.out.println("Product found at index " + resultBinary + " using binary search");
        } else {
            System.out.println("Product not found using binary search");
        }
    }
}
