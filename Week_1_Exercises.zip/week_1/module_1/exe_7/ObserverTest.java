public class ObserverTest {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();
        
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();
        
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);
        
        stockMarket.setPrice(150.0);
        stockMarket.setPrice(160.0);
    }
}
