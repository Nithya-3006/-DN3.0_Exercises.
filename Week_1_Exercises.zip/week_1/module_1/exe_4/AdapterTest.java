public class AdapterTest {
    public static void main(String[] args) {
        PaymentProcessor paypal = new PayPalAdapter(new PayPal());
        paypal.processPayment(100.0);

        PaymentProcessor stripe = new StripeAdapter(new Stripe());
        stripe.processPayment(200.0);
    }
}
