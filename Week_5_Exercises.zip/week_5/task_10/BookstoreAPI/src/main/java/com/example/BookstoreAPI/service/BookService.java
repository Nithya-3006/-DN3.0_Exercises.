package com.example.BookstoreAPI.service;


import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookstoreAPI.model.Book;
import com.example.BookstoreAPI.repository.BookRepository;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final Counter bookCounter;

    @Autowired
    public BookService(BookRepository bookRepository, MeterRegistry meterRegistry) {
        this.bookRepository = bookRepository;
        this.bookCounter = meterRegistry.counter("book.created");
    }

    public Book createBook(Book book) {
        bookCounter.increment(); 
        return bookRepository.save(book);
    }

    
}
