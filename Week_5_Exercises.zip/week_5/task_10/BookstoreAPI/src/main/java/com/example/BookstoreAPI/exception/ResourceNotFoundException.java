package com.example.BookstoreAPI.exception;

public class ResourceNotFoundException {
	public ResourceNotFoundException(String message) {
        super();
    }
}
