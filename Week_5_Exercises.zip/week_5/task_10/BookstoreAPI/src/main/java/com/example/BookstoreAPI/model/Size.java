package com.example.BookstoreAPI.model;

public @interface Size {

	int max();

	String message();

	int min();

}
