package com.example.BookstoreAPI.model;

public @interface Min {

}
