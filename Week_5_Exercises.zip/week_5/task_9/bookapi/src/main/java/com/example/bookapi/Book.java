package com.example.bookapi;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String title;
    private String author;
    private String isbn;
    private double price;
	public Object getTitle() {
		return null;
	}
	public void setTitle(Object title2) {
		
	}
	public Object getAuthor() {
		
		return null;
	}
	public Object getIsbn() {
		
		return null;
	}
	public Object getPrice() {
		
		return null;
	}
	public void setAuthor(Object author2) {
		
	}
	public void setIsbn(Object isbn2) {	
		
	}
	public void setPrice(Object price2) {	
		
	}
	public Long getId() {
		return null;
	}

    
}

