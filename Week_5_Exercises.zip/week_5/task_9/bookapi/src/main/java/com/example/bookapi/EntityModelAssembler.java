package com.example.bookapi;

import org.springframework.hateoas.EntityModel;

public class EntityModelAssembler<T> {

	public EntityModel<Book> toModel(Book book) {
		
		return null;
	}

}
