package com.example.bookapi;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
public class BookController {
    
    @Autowired
    private BookService bookService;
    
    @Autowired
    private EntityModelAssembler<Book> bookAssembler;

    @GetMapping
    public CollectionModel<EntityModel<Book>> getAllBooks() {
        List<EntityModel<Book>> books = bookService.getAllBooks().stream()
            .map(bookAssembler::toModel)
            .collect(Collectors.toList());
        
        return CollectionModel.of(books, 
            ((Object) linkTo(methodOn(BookController.class).getAllBooks())).withSelfRel());
    }

    private Object linkTo(CollectionModel<EntityModel<Book>> allBooks) {
		
		return null;
	}

	private BookController methodOn(Class<BookController> class1) {
		
		return null;
	}

	@GetMapping("/{id}")
    public EntityModel<Book> getBookById(@PathVariable Long id) {
        Book book = bookService.getBookById(id);
        return bookAssembler.toModel(book);
    }

    @PostMapping
    public ResponseEntity<EntityModel<Book>> createBook(@RequestBody Book book) {
        Book newBook = bookService.createBook(book);
        return ResponseEntity
            .created(linkTo(methodOn(BookController.class).getBookById(newBook.getId())).toUri())
            .body(bookAssembler.toModel(newBook));
    }

    private Object linkTo(EntityModel<Book> bookById) {
		
		return null;
	}

	@PutMapping("/{id}")
    public ResponseEntity<EntityModel<Book>> updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
        Book updatedBook = bookService.updateBook(id, bookDetails);
        return ResponseEntity.ok(bookAssembler.toModel(updatedBook));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }
}

