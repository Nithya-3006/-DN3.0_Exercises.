package com.example.bookapi;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport;
import org.springframework.stereotype.Component;

@Component
public class BookAssembler extends RepresentationModelAssemblerSupport<Book, EntityModel<Book>> {

    public BookAssembler() {
        super(BookController.class, EntityModel.class);
    }

    @Override
    public EntityModel<Book> toModel(Book book) {
        return EntityModel.of(book,
            linkTo(methodOn(BookController.class).getBookById(book.getId())).withSelfRel(),
            linkTo(methodOn(BookController.class).getAllBooks()).withRel("books"));
    }

	private BookController methodOn(Class<BookController> class1) {
		
		return null;
	}
}
