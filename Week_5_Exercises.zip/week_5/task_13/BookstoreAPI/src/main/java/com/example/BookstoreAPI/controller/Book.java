package com.example.BookstoreAPI.controller;

public class Book {

	public Book(long l, String string, String string2) {
		
	}

}
