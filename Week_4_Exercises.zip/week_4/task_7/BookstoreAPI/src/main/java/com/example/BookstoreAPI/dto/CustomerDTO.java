package com.example.BookstoreAPI.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;
    private String address;

    @JsonCreator
    public CustomerDTO(@JsonProperty("customer_name") String name, 
                       @JsonProperty("customer_email") String email) {
        this.name = name;
        this.email = email;
    }

    // Getters and Setters
}

