INSERT INTO books (title, author, price, isbn) VALUES ('Spring Boot in Action', 'Craig Walls', 29.99, '9781617292545');
INSERT INTO books (title, author, price, isbn) VALUES ('Effective Java', 'Joshua Bloch', 45.00, '9780134685991');
