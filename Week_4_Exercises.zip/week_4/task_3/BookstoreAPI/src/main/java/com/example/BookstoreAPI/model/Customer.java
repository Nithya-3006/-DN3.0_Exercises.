package com.example.BookstoreAPI.model;



import jakarta.annotation.Generated;

@jakarta.persistence.Entity
public class Customer {
    @jakarta.persistence.Id
   // @Generated(comments = Generated.IDENTITY, value = { "" })
    private Long id;
    private String name;
    private String email;
    private String address;
	public void setName(String string) {
		
		
	}
	public void setEmail(String string) {
		
		
	}
	public void setAddress(String string) {
		
		
	}

   
}
