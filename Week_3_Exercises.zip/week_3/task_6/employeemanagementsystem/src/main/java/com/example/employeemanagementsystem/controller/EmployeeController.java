package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.model.Employee;
import com.example.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/department/{departmentId}")
    public Page<Employee> getEmployeesByDepartmentId(@PathVariable Long departmentId, Pageable pageable) {
        return employeeRepository.findByDepartmentId(departmentId, pageable);
    }

    @GetMapping("/lastname/{lastName}")
    public Page<Employee> getEmployeesByLastName(@PathVariable String lastName, Pageable pageable) {
        return employeeRepository.findByLastName(lastName, pageable);
    }

    
}
