package com.example.EmployeeManagementSystem;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import jakarta.persistence.*;
import java.util.List;

@SpringBootApplication
public class EmployeeManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementSystemApplication.class, args);
    }
    @Entity
    @Table(name = "employees")
    public static class Employee {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        private String firstName;
        private String lastName;
        private String email;
        
        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "department_id")
        private Department department;
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getFirstName() { return firstName; }
        public void setFirstName(String firstName) { this.firstName = firstName; }
        public String getLastName() { return lastName; }
        public void setLastName(String lastName) { this.lastName = lastName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public Department getDepartment() { return department; }
        public void setDepartment(Department department) { this.department = department; }
    }
    @Entity
    @Table(name = "departments")
    public static class Department {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        private String name;

        @OneToMany(mappedBy = "department")
        private List<Employee> employees;

        public Long getId() 
        { 
        	return id; 
        }
        public void setId(Long id) 
        { 
        	this.id = id; 
        }
        public String getName() { 
        	return name; 
        }
        public void setName(String name) {
        	this.name = name; 
        }
        public List<Employee> getEmployees() {
        	return employees; 
        }
        public void setEmployees(List<Employee> employees) { 
        	this.employees = employees; 
        }
    }

    public interface EmployeeRepository extends JpaRepository<Employee, Long> {}
    public interface DepartmentRepository extends JpaRepository<Department, Long> {}

    @Service
    public static class EmployeeService {
        private final EmployeeRepository repo;
        public EmployeeService(EmployeeRepository repo) {
            this.repo = repo;
        }
        public List<Employee> getAll() {
            return repo.findAll();
        }
        public Employee save(Employee employee) {
            return repo.save(employee);
        }
    }

    @Service
    public static class DepartmentService {
        private final DepartmentRepository repo;
        public DepartmentService(DepartmentRepository repo) {
            this.repo = repo;
        }
        public List<Department> getAll() {
            return repo.findAll();
        }
        public Department save(Department department) {
            return repo.save(department);
        }
    }

    @RestController
    @RequestMapping("/employees")
    public static class EmployeeController {
        private final EmployeeService service;
        public EmployeeController(EmployeeService service) {
            this.service = service;
        }
        @GetMapping
        public List<Employee> getAll() {
            return service.getAll();
        }
        @PostMapping
        public Employee create(@RequestBody Employee employee) {
            return service.save(employee);
        }
    }

    @RestController
    @RequestMapping("/departments")
    public static class DepartmentController {
        private final DepartmentService service;
        public DepartmentController(DepartmentService service) {
            this.service = service;
        }
        @GetMapping
        public List<Department> getAll() {
            return service.getAll();
        }
        @PostMapping
        public Department create(@RequestBody Department department) {
            return service.save(department);
        }
    }

    @Bean
    public CommandLineRunner initData(EmployeeRepository employeeRepo, DepartmentRepository departmentRepo) {
        return (args) -> {
            Department hr = new Department();
            hr.setName("Human Resources");
            departmentRepo.save(hr);

            Department it = new Department();
            it.setName("IT");
            departmentRepo.save(it);

            Employee emp1 = new Employee();
            emp1.setFirstName("John");
            emp1.setLastName("Doe");
            emp1.setEmail("john.doe@example.com");
            emp1.setDepartment(hr);
            employeeRepo.save(emp1);

            Employee emp2 = new Employee();
            emp2.setFirstName("Jane");
            emp2.setLastName("Smith");
            emp2.setEmail("jane.smith@example.com");
            emp2.setDepartment(it);
            employeeRepo.save(emp2);
        };
    }
}
