package com.example.employee_management_system.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String email;

    @ManyToOne
    private Department department;

	public Object getName() {
		
		return null;
	}

	public Object getEmail() {
		return null;
	}

	public Object getDepartment() {
		return null;
	}

	public void setName(Object name2) {
		
	}

	public void setEmail(Object email2) {
		
	}

	public void setDepartment(Object department2) {
		
	}  
}
