package com.example.employee_management_system.repository;

import org.springframework.stereotype.Repository;

import com.example.employee_management_system.Department;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    List<Department> findByName(String name);

}
