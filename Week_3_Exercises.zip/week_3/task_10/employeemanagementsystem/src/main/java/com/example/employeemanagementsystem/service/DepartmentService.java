package com.example.employeemanagementsystem.service;

public class DepartmentService {

}
