package com.example.employeemanagementsystem.repository;



import com.example.employeemanagementsystem.dto.EmployeeDto;
import com.example.employeemanagementsystem.model.Employee;
import com.example.employeemanagementsystem.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<EmployeeProjection> findAllBy();
    
    @Query("SELECT new com.example.employeemanagement.dto.EmployeeDto(e.id, e.firstName, e.lastName) FROM Employee e")
    List<EmployeeDto> findAllEmployeeDtos();
}
