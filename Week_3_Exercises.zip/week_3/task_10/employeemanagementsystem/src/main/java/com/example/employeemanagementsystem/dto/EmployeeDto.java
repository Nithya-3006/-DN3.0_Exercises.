package com.example.employeemanagementsystem.dto;

public class EmployeeDto {

}
