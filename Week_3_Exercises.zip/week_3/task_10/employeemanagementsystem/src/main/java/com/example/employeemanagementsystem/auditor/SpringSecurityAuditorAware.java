package com.example.employeemanagementsystem.auditor;

public class SpringSecurityAuditorAware {

}
