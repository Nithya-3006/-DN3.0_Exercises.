package com.example.employeemanagementsystem.projection;

public class EmployeeProjection {

}
