package com.library.management;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.management.BookService;
import com.library.management.Book;

/**
 * Hello world!
 *
 */
public class App 
{
	
	    public static void main(String[] args) {
	    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	        BookService bookService = context.getBean(BookService.class);
	        Book book = new Book(1, "The Great Gatsby", "F. Scott Fitzgerald", "9780743273565", 1925);
	        bookService.addBook(book);
	        System.out.println("Book added: " + book);
	    }
	

}





