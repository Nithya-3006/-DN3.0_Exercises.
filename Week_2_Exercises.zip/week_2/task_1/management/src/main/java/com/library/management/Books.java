package com.library.management;


public interface Books {
	void book();
}
