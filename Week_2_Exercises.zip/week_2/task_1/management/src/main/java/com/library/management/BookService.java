package com.library.management;

import org.springframework.stereotype.Component;


@Component
public class BookService implements Books {
	public void book() {
		System.out.println("You are in Book service class");
	}
}
