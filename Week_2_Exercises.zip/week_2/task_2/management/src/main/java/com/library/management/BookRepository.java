package com.library.management;

import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class BookRepository extends Books{
	private List<Books> books = new ArrayList<>();
    public void save(Books book) {
        books.add(book);
        System.out.println("Book saved: " + book);
    }
    public List<Books> findAll() {
        return books;
    }
    public Books findById(String id) {
        return books.stream()
                    .filter(book -> book.getId().equals(id))
                    .findFirst()
                    .orElse(null);
    }
}


    


