package com.library.management;

import org.springframework.stereotype.Component;

@Component
public class BookService extends Books {
	private BookRepository bookRepository;
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
    public void addBook(Books book) {
        bookRepository.save(book);
    }
}




