package com.library.management;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        
        
        BookService bookService = (BookService) context.getBean("bookService");
        Books book = new Books("123", "Spring Framework", "Author Name");
        bookService.addBook(book);
        System.out.println("Book added successfully!");
        
    }
}
