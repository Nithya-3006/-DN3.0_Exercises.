package com.library.management;

public class BookService {
    private BookRepository bookRepository;

    // Setter method for Spring to inject the dependency
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Business logic method
    public void someBusinessMethod() {
        // Add some books to the repository
        bookRepository.addBook(new Book(1, "1984", "George Orwell"));
        bookRepository.addBook(new Book(2, "To Kill a Mockingbird", "Harper Lee"));

        // Retrieve and print all books
        System.out.println("List of all books:");
        for (Book book : bookRepository.getAllBooks()) {
            System.out.println(book);
        }

        // Find a book by id and print it
        Book book = bookRepository.findBookById(1);
        if (book != null) {
            System.out.println("Book found with ID 1: " + book);
        } else {
            System.out.println("Book not found with ID 1");
        }
    }
}
